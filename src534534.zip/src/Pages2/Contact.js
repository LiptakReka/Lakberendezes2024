import React from 'react'
import "./Contact.css"

const Contact = () => {
  const roomLabContacts = [
    {
      name: "Lipták Réka Manuéla",
      phone: "+36 30-927-0458",
      email: "liptakr@kkszki.hu"
    },
    {
      name: "Mészáros Vivien Lara",
      phone: "+36 30-458-2020",
      email: "meszarosv@kkszki.hu"
    }
  ];

  const businessContacts = [
    {
      name: "Bogart Bútor",
      phone: "+36 1-808-9860",
      email: "info@bogart-butor.hu"
    },
    {
      name: "Alaba",
      phone: "+36 30-366-1576",
      email: "info@alaba.hu"
    },
    {
      name: "XXXLutz",
      phone: "+36 23-801-911",
      email: "shop@xxxlutz.hu"
    },
    {
      name: "BRW Bútorház",
      phone: "+36 70-401-2044",
      email: "rob.butorhaz@gmail.com"
    },
    {
      name: "JYSK",
      phone: "+36 1-701-4222",
      email: "vevoszolgalat-hu@jysk.com"
    },
    {
      name: "Möbelix",
      phone: "+36 46-814-113",
      email: "info@moebelix.hu"
    },
    {
      name: "Zondo",
      phone: "+36 1-550-7605",
      email: "info@zondo.hu"
    },
    {
      name: "Soma bútor",
      phone: "+36 70-797-5817",
      email: "info@somabutor.hu"
    },
    {
      name: "Bútor7",
      phone: "nem áll rendelkezésre",
      email: "info@butor7.hu"
    },
    {
      name: "Bútorline",
      phone: "+36 20-273-0605",
      email: "info@butorline.hu"
    },
    {
      name: "RS Bútor",
      phone: "+36 1-329-0050",
      email: "rsinfo@rs.hu"
    },
    {
      name: "IKEA",
      phone: "+36 1-808-9230",
      email: "nem áll rendelkezésre"
    },
    {
      name: "Magyar Bútorbolt",
      phone: "nem áll rendelkezésre",
      email: "megrendeles@magyarbutorbolt.hu"
    },
    {
      name: "Butlers",
      phone: "+36 30-726-9588",
      email: "home@butlers.hu"
    }
  ];

  const ContactCard = ({ name, phone, email }) => (
    <div className="contact-card">
      <h3 className="contact-name">{name}</h3>
      <p className="contact-phone">
        <span className="label">Tel:</span> {phone}
      </p>
      {email !== "nem áll rendelkezésre" ? (
        <a href={`mailto:${email}`} className="contact-email">
          {email}
        </a>
      ) : (
        <p className="email-unavailable">Email nem áll rendelkezésre</p>
      )}
    </div>
  );

  return (
    <div className="contact-page">
      <div className="container">
        <h1 className="main-title">
          Bármi panasz felmesülése érdekében keresse az alábbi szolgáltatásokat!
        </h1>

        <div className="section">
          <h2 className="section-title">RoomLab elérhetőségek</h2>
          <div className="roomlab-contacts">
            {roomLabContacts.map((contact, index) => (
              <ContactCard key={index} {...contact} />
            ))}
          </div>
        </div>

        <div className="section">
          <h2 className="section-title">Egyéb üzleti elérhetőségek</h2>
          <div className="business-contacts">
            {businessContacts.map((contact, index) => (
              <ContactCard key={index} {...contact} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Contact;
